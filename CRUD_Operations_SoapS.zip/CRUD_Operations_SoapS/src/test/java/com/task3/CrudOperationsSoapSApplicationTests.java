package com.task3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOperationsSoapSApplicationTests {

	@Test
	void contextLoads() {
	}

}
