package com.task3.structure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperationsSoapSApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperationsSoapSApplication.class, args);
	}

}
