package com.task3.services;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task3.structure.Customer;
import com.task3.repository.CustomerRepository;

@Service
@WebService
public class CustomerService {
    private CustomerRepository customerRepository;

    @Autowired
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @WebMethod
    public void createCustomer(Customer customer) {
        customerRepository.save(customer);
    }

    @WebMethod
    public Customer readCustomer(int id) {
        return customerRepository.findById(id).orElse(null);
    }

    @WebMethod
    public void updateCustomer(Customer customer) {
    	customerRepository.save(customer);
    }

    @WebMethod
    public void deleteCustomer(int id) {
    	customerRepository.deleteById(id);
    }
}