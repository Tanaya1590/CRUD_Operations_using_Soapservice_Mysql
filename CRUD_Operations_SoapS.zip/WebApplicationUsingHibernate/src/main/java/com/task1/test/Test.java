package com.task1.test;



import org.hibernate.Session;
import org.hibernate.Transaction;

import com.task1.EmployeeInfo;
import com.task1.util.HibernateUtil;

public class Test {
	public static void main(String[] args) {
		Transaction tx=null;
		try(Session ses=HibernateUtil.getSf().openSession()){
		tx=ses.beginTransaction();
		EmployeeInfo e=new EmployeeInfo();
		e.setEmpName("ABCD");
		e.setPhone(122345);
		e.setEmail("Pune");
		e.setEmail("abc@gmail.com");
		e.setImage("C:\\Users\\Dell\\Pictures\\hos1");
		//set data
		
		ses.save(e);
		tx.commit();
		}catch(Exception e) {
		//tx.rollback();
		e.printStackTrace();

	}

}

}
