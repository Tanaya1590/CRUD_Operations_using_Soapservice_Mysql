package com.task1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;

@Entity
	@Table(name="bluebriclsdb")
	public class EmployeeInfo {
		
	
		private String name;
	
		private int phone;
	
		private String email;
	
		private String address;
	
		private String image;
		
		private String empName;
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public int getPhone() {
			return phone;
		}
		public void setPhone(int phone) {
			this.phone = phone;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
		public void setImage(String string) {
			this.image = string;
		}
		@Override
		public String toString() {
			return "EmployeeInfo [name=" + name + ", phone=" + phone + ", email=" + email + ", address=" + address
					+ ", image=" + image + ", empName=" + empName + "]";
		}
		
	}

