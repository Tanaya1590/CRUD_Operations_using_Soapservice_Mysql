package com.task4.models;

import com.task4.models.Product;

public class Test {
	
	public static void main(String[]args) {
		Product p=new Product();
		p.setId(111);
		p.setName("Realme");
		p.setPrice(15000);

	}
	
	


}
